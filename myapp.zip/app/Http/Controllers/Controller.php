<?php

namespace App\Http\Controllers;
use App\Models\Branch;

abstract class Controller
{
    //
}

